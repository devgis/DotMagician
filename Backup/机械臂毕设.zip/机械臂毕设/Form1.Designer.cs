﻿namespace 参观程序
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_X = new System.Windows.Forms.TextBox();
            this.textBox_Y = new System.Windows.Forms.TextBox();
            this.textBox_Z = new System.Windows.Forms.TextBox();
            this.textBox_R = new System.Windows.Forms.TextBox();
            this.button_GetL = new System.Windows.Forms.Button();
            this.button_move = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_M = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button_ptptest = new System.Windows.Forms.Button();
            this.button_ptptest2 = new System.Windows.Forms.Button();
            this.button_savepoint = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(32, 34);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 51);
            this.button1.TabIndex = 0;
            this.button1.Text = "连接设备";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(414, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "X:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(412, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Y:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(411, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "Z:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(414, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "R:";
            // 
            // textBox_X
            // 
            this.textBox_X.Location = new System.Drawing.Point(472, 51);
            this.textBox_X.Name = "textBox_X";
            this.textBox_X.Size = new System.Drawing.Size(112, 28);
            this.textBox_X.TabIndex = 5;
            // 
            // textBox_Y
            // 
            this.textBox_Y.Location = new System.Drawing.Point(472, 94);
            this.textBox_Y.Name = "textBox_Y";
            this.textBox_Y.Size = new System.Drawing.Size(112, 28);
            this.textBox_Y.TabIndex = 6;
            // 
            // textBox_Z
            // 
            this.textBox_Z.Location = new System.Drawing.Point(472, 134);
            this.textBox_Z.Name = "textBox_Z";
            this.textBox_Z.Size = new System.Drawing.Size(112, 28);
            this.textBox_Z.TabIndex = 7;
            // 
            // textBox_R
            // 
            this.textBox_R.Location = new System.Drawing.Point(472, 180);
            this.textBox_R.Name = "textBox_R";
            this.textBox_R.Size = new System.Drawing.Size(112, 28);
            this.textBox_R.TabIndex = 8;
            // 
            // button_GetL
            // 
            this.button_GetL.Location = new System.Drawing.Point(32, 98);
            this.button_GetL.Name = "button_GetL";
            this.button_GetL.Size = new System.Drawing.Size(144, 54);
            this.button_GetL.TabIndex = 9;
            this.button_GetL.Text = "获取位置";
            this.button_GetL.UseVisualStyleBackColor = true;
            this.button_GetL.Click += new System.EventHandler(this.button_GetL_Click);
            // 
            // button_move
            // 
            this.button_move.Location = new System.Drawing.Point(32, 174);
            this.button_move.Name = "button_move";
            this.button_move.Size = new System.Drawing.Size(144, 56);
            this.button_move.TabIndex = 10;
            this.button_move.Text = "移动位置";
            this.button_move.UseVisualStyleBackColor = true;
            this.button_move.Click += new System.EventHandler(this.button_move_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(414, 234);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 18);
            this.label5.TabIndex = 11;
            this.label5.Text = "M:";
            // 
            // textBox_M
            // 
            this.textBox_M.Location = new System.Drawing.Point(472, 228);
            this.textBox_M.Name = "textBox_M";
            this.textBox_M.Size = new System.Drawing.Size(112, 28);
            this.textBox_M.TabIndex = 12;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(32, 248);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(144, 53);
            this.button2.TabIndex = 13;
            this.button2.Text = "启用滑轨";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(32, 316);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(144, 45);
            this.button3.TabIndex = 14;
            this.button3.Text = "获取滑轨位置";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button_ptptest
            // 
            this.button_ptptest.Location = new System.Drawing.Point(80, 434);
            this.button_ptptest.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ptptest.Name = "button_ptptest";
            this.button_ptptest.Size = new System.Drawing.Size(112, 34);
            this.button_ptptest.TabIndex = 15;
            this.button_ptptest.Text = "PTPTest";
            this.button_ptptest.UseVisualStyleBackColor = true;
            this.button_ptptest.Click += new System.EventHandler(this.button_ptptest_Click);
            // 
            // button_ptptest2
            // 
            this.button_ptptest2.Font = new System.Drawing.Font("宋体", 35F);
            this.button_ptptest2.Location = new System.Drawing.Point(279, 327);
            this.button_ptptest2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ptptest2.Name = "button_ptptest2";
            this.button_ptptest2.Size = new System.Drawing.Size(417, 141);
            this.button_ptptest2.TabIndex = 16;
            this.button_ptptest2.Text = "Start";
            this.button_ptptest2.UseVisualStyleBackColor = true;
            this.button_ptptest2.Click += new System.EventHandler(this.button_ptptest2_Click);
            // 
            // button_savepoint
            // 
            this.button_savepoint.Location = new System.Drawing.Point(734, 507);
            this.button_savepoint.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_savepoint.Name = "button_savepoint";
            this.button_savepoint.Size = new System.Drawing.Size(112, 34);
            this.button_savepoint.TabIndex = 17;
            this.button_savepoint.Text = "保存点";
            this.button_savepoint.UseVisualStyleBackColor = true;
            this.button_savepoint.Click += new System.EventHandler(this.button_savepoint_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 560);
            this.Controls.Add(this.button_savepoint);
            this.Controls.Add(this.button_ptptest2);
            this.Controls.Add(this.button_ptptest);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox_M);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button_move);
            this.Controls.Add(this.button_GetL);
            this.Controls.Add(this.textBox_R);
            this.Controls.Add(this.textBox_Z);
            this.Controls.Add(this.textBox_Y);
            this.Controls.Add(this.textBox_X);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_X;
        private System.Windows.Forms.TextBox textBox_Y;
        private System.Windows.Forms.TextBox textBox_Z;
        private System.Windows.Forms.TextBox textBox_R;
        private System.Windows.Forms.Button button_GetL;
        private System.Windows.Forms.Button button_move;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_M;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button_ptptest;
        private System.Windows.Forms.Button button_ptptest2;
        private System.Windows.Forms.Button button_savepoint;
    }
}

