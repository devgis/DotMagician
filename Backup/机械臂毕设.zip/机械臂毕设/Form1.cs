﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dobot;
using System.Threading;
using System.IO;

namespace 参观程序
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StartDobot();
            SetParam();

        }

        private void StartDobot()
        {
            StringBuilder fwType = new StringBuilder(60);
            StringBuilder version = new StringBuilder(60);
        
            int ret = DobotDll.ConnectDobot("", 115200, fwType, version);
            // start connect
            if (ret != (int)DobotConnect.DobotConnect_NoError)
            {
                Console.WriteLine("Connect error");
                return;
            }
            Console.WriteLine("Connect success");

           // isConnectted = true;
            DobotDll.SetCmdTimeout(3000);

            // Must set when sensor is not exist
            //DobotDll.ResetPose(true, 45, 45);

            // Get name
            string deviceName = "LCFCPA_Dobot";
            DobotDll.SetDeviceName(deviceName);

            StringBuilder deviceSN = new StringBuilder(64);
            DobotDll.GetDeviceName(deviceSN, 64);

            Console.WriteLine(ret);
            //SetParam();

            //AlarmTest();
            DobotDll.SetQueuedCmdClear();

            DobotDll.SetDeviceWithL(true, false, 500);

        }

        private void button_GetL_Click(object sender, EventArgs e)
        {
            Pose pose = new Pose();
            DobotDll.GetPose(ref pose);
            textBox_R.Text = pose.rHead.ToString();
            textBox_X.Text = pose.x.ToString();
            textBox_Y.Text = pose.y.ToString();
            textBox_Z.Text = pose.z.ToString();

            float l = 0;
            DobotDll.GetPoseL(ref l).ToString();
            textBox_M.Text = l.ToString();
        }

        private void button_move_Click(object sender, EventArgs e)
        {
            DobotDll.SetQueuedCmdClear();
            HOMEParams xyz = new HOMEParams();
            xyz.x = float.Parse(textBox_X.Text);
            xyz.y = float.Parse(textBox_Y.Text);
            xyz.z = float.Parse(textBox_Z.Text);
            xyz.r = float.Parse(textBox_R.Text);
            ulong ul = 100;
            DobotDll.SetHOMEParams(ref xyz, false, ref ul);

            HOMECmd home = new HOMECmd();
            UInt64 sss = 1;
            DobotDll.SetHOMECmd(ref home, false, ref sss);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DobotDll.SetDeviceWithL(true, false, 500);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            float l = 0;
           DobotDll.GetPoseL(ref l).ToString();
            textBox_M.Text = l.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_ptptest_Click(object sender, EventArgs e)
        {
            //ptp(byte.Parse("1"), -25, 31, 3, 22);
       
            ptp((byte)1, 67.99f, 216.4f, -27.99f, 0);
            Thread.Sleep(2000);
            ptp((byte)2, 77.99f, 116.4f, -21.99f, 0);
            Thread.Sleep(2000);
            ptp((byte)2, 37.99f, 116.4f, -21.99f, 0);
            Thread.Sleep(2000);
            ptp((byte)2, 27.99f, 116.4f, -21.99f, 0);
            Thread.Sleep(2000);
            ptp((byte)2, 88.99f, 116.4f, -21.99f, 0);
        }

        private void SetParam()
        {
            UInt64 cmdIndex = 0;
            JOGJointParams jsParam;
            jsParam.velocity = new float[] { 200, 200, 200, 200 };
            jsParam.acceleration = new float[] { 200, 200, 200, 200 };
            DobotDll.SetJOGJointParams(ref jsParam, false, ref cmdIndex);

            JOGCommonParams jdParam;
            jdParam.velocityRatio = 100;
            jdParam.accelerationRatio = 100;
            DobotDll.SetJOGCommonParams(ref jdParam, false, ref cmdIndex);

            PTPJointParams pbsParam;
            pbsParam.velocity = new float[] { 200, 200, 200, 200 };
            pbsParam.acceleration = new float[] { 200, 200, 200, 200 };
            DobotDll.SetPTPJointParams(ref pbsParam, false, ref cmdIndex);

            PTPCoordinateParams cpbsParam;
            cpbsParam.xyzVelocity = 100;
            cpbsParam.xyzAcceleration = 100;
            cpbsParam.rVelocity = 100;
            cpbsParam.rAcceleration = 100;
            DobotDll.SetPTPCoordinateParams(ref cpbsParam, false, ref cmdIndex);

            PTPJumpParams pjp;
            pjp.jumpHeight = 20;
            pjp.zLimit = 100;
            DobotDll.SetPTPJumpParams(ref pjp, false, ref cmdIndex);

            PTPCommonParams pbdParam;
            pbdParam.velocityRatio = 30;
            pbdParam.accelerationRatio = 30;
            DobotDll.SetPTPCommonParams(ref pbdParam, false, ref cmdIndex);

            PTPLParams ptpSet = new PTPLParams();
            ptpSet.velocity = 400;
            ptpSet.acceleration = 400;
            DobotDll.SetPTPLParams(ref ptpSet, false, ref cmdIndex);

            JOGLParams jogLParam;                 //设置带滑轨的点动速度和加速度
            jogLParam.velocity = 30;
            jogLParam.acceleration = 30;
            DobotDll.SetJOGLParams(ref jogLParam, false, ref cmdIndex);
        }

        private UInt64 ptp(byte style, float x, float y, float z, float r)
        {
            PTPCmd pdbCmd;
            UInt64 cmdIndex = 0;

            pdbCmd.ptpMode = style;
            pdbCmd.x = x;
            pdbCmd.y = y;
            pdbCmd.z = z;
            pdbCmd.rHead = r;
            while (true)
            {
                int ret = DobotDll.SetPTPCmd(ref pdbCmd, false, ref cmdIndex);
                if (ret == 0)
                    break;
            }

            return cmdIndex;
        }
        private void MoveL(float x, float y, float z, float m)
        {
            ulong ul = 0;
            PTPWithLCmd cmd = new PTPWithLCmd();
            cmd.x = x;
            cmd.y = y;
            cmd.z = z;
            cmd.rHead = 0;
            cmd.l = m;

            cmd.ptpMode = (byte)1;

            while (true)
            {
                int ret = DobotDll.SetPTPWithLCmd(ref cmd, false, ref ul);
                Console.WriteLine(ret);
                if (ret == 0)
                    break;
            }
        }
        private void button_ptptest2_Click(object sender, EventArgs e)
        {
            MoveL(257.5833f, -90.59064f, -26.86404f, 0f);
            Thread.Sleep(2000);
            MoveL(285.1729f, 14.76902f, -16.23297f, 0f);
            Thread.Sleep(2000);
            MoveL(272.6722f, -92.0918f, -25.35905f, 0f);


        }

        private void button_savepoint_Click(object sender, EventArgs e)
        {
            File.AppendAllText("log.log", $" MoveL({textBox_X.Text}f, {textBox_Y.Text}f, {textBox_Z.Text}f,{textBox_M.Text}f );{Environment.NewLine}");
        }
    }

}
